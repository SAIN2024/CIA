using Cia.Core;

var passed = 0;
void Assert(bool condition, string message)
{
    if (!condition) throw new Exception(message);
    passed++;
}
Resource pool = new("pool:storage", ResourceKind.Pool, "plcnext", "storage");
Resource file = new("file:log", ResourceKind.Identity, "plcnext", "file", pool.Id);
Resource controlFile = new("file:control", ResourceKind.Identity, "plcnext", "file", pool.Id);
var oldDeployment = new Deployment
{
    Id = "old", Platform = "PLCnext",
    Services = [new("logging", "PLCnext"), new("control", "PLCnext")],
    Resources = [pool, file, controlFile],
    Dependencies = [
        new("logging", file.Id, "log", EvidenceSource.Configuration, "file access"),
        new("control", controlFile.Id, "save", EvidenceSource.Runtime, "file status")],
    Probes = [new("save-check", ProbeType.StatusEquals, "status.txt", "OK")],
    Workloads = [new("sustained-logging")],
    Acceptances = [new("save-preserved", "control", "save", "sustained-logging", "save-check", "file operation succeeds")]
};
var newDeployment = new Deployment
{
    Id = "new", Platform = "PLCnext", Services = oldDeployment.Services, Resources = oldDeployment.Resources,
    Dependencies = oldDeployment.Dependencies, Probes = oldDeployment.Probes,
    Workloads = oldDeployment.Workloads, Acceptances = oldDeployment.Acceptances
};
var graph = new ServiceResourceGraph(oldDeployment);
graph.Validate();
Assert(graph.DependenciesFor("control", "save").Contains("pool:storage"), "pool closure missing");
var changes = new List<Change> { new("C1", "logging", "increase retention", ExplicitResources: ["file:log"]) };
var impacts = ImpactAnalyzer.Analyze(graph, new ServiceResourceGraph(newDeployment), changes);
Assert(impacts.Count == 1 && impacts[0].Affected.Count == 1, "unchanged control service not selected");
var tests = TestGenerator.Generate(impacts);
Assert(tests.Count == 1 && tests[0].AffectedService == "control", "preservation test missing");
Assert(TestGenerator.Deduplicate(tests.Concat(tests)).Count == 1, "duplicate tests not collapsed");
var bogus = tests[0] with { ProbeId = "unknown" };
Assert(TestGenerator.ValidateGenerated([bogus], impacts, oldDeployment, newDeployment).Count == 0,
    "ungrounded LLM candidate accepted");
Observation Obs(string deployment, bool pass) => new(deployment, "control", "save", "sustained-logging", "save-check", pass,
    pass ? "OK" : "ERROR", DateTimeOffset.UtcNow);
var context = new RunContext("state-a", "inputs-a", "services-a", 10000, "persistent-a", "oracle-v1");
var before = new ValidationSnapshot("old", [Obs("old", true)], [], context);
var evidence = new Evidence(tests[0].Id, "pool:storage", EvidenceSource.PoolCorrelation,
    "Controller file operation failed as storage demand increased", true, true);
var after = new ValidationSnapshot("new", [Obs("new", false)], [evidence], context);
var rollback = new ValidationSnapshot("restored", [Obs("restored", true)], []);
var finding = AuditValidator.Validate(tests[0], before, after, rollback);
Assert(AuditValidator.Validate(tests[0], before, after with { Context = context with { InputTraceHash = "different" } }, null).Outcome == Outcome.Unsupported,
    "mismatched external inputs accepted");
Assert(finding.Outcome == Outcome.ConfirmedInterference, "corroborated interference not detected");
Assert(finding.ReversalRestored == true, "reversal not recorded");
Assert(AuditValidator.Validate(tests[0], before, new ValidationSnapshot("new", [Obs("new", true)], [], context), null).Outcome == Outcome.NotReproduced, "false regression");
Assert(AuditValidator.Validate(tests[0], before, new ValidationSnapshot("new", [Obs("new", false)], [], context), null).Outcome == Outcome.RegressionUnresolved, "uncorroborated regression mislabeled");
Assert(AuditValidator.Validate(tests[0], null, after, null).Outcome == Outcome.Unsupported, "baseline absent but positive");
var report = await Auditor.RunAsync(new AuditInput {
    Baseline = oldDeployment, Updated = newDeployment, Changes = changes,
    BaselineSnapshot = before, UpdatedSnapshot = after, ReversalSnapshot = rollback
});
Assert(report.Summary["regressions"] == 1 && report.Summary["unchangedServiceRegressions"] == 1, "audit summary incorrect");
Console.WriteLine($"PASS: {passed} assertions");
