#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
dotnet build src/Cia.Cli/Cia.Cli.csproj -c Release
dotnet run --project tests/Cia.Tests/Cia.Tests.csproj -c Release
dotnet run --project src/Cia.Cli/Cia.Cli.csproj -c Release -- audit examples/siemens-namespace.json reports/siemens.json
dotnet run --project src/Cia.Cli/Cia.Cli.csproj -c Release -- audit examples/plcnext-storage.json reports/plcnext.json
