# CIA — Cross-Service Interference Auditor

C#/.NET implementation of the pre-deployment, four-stage architecture in **CIA: Automated Auditing of Cross-Service Interference in Programmable Logic Controllers** (latest supplied 11-page manuscript).

## Requirements

.NET 8 SDK; no external NuGet packages. The core and replay mode operate offline. Live staging operations require connectivity and credentials controlled by the operator.

## Quick start

```bash
dotnet run --project src/Cia.Cli -- audit examples/siemens-namespace.json reports/siemens.json
dotnet run --project src/Cia.Cli -- audit examples/plcnext-storage.json reports/plcnext.json
dotnet run --project src/Cia.Cli -- inspect examples/siemens-baseline-deployment.json
dotnet run --project tests/Cia.Tests
```

The example snapshots are **illustrative input fixtures, not experimental evidence** and do not reproduce the published 30-scenario evaluation. In particular, their regressions are correctly marked *unresolved* when independent resource evidence is absent.

For authorized, read-only staging probes:

```bash
dotnet run --project src/Cia.Cli -- collect examples/siemens-baseline-deployment.json snapshots/baseline.json
```

Replace example target addresses with those of a designated staging PLC; the reserved example address is not an operational controller. Match initial state, workloads, observation windows and persistent storage manually through the controller test harness. The `collect` command performs simple read-only checks; it does not deploy PLC software or emulate physical plant dynamics.

## Optional LLM test suggestions

The auditor always generates resource-grounded deterministic preservation tests. Optionally, provide a Chat Completions-compatible model API:

```bash
export CIA_LLM_ENDPOINT=https://YOUR_APPROVED_ENDPOINT/v1/chat/completions
export CIA_LLM_MODEL=YOUR_MODEL_ID
export CIA_LLM_API_KEY=YOUR_API_KEY
dotnet run --project src/Cia.Cli -- audit examples/plcnext-storage.json reports/llm.json --llm
```

Model suggestions must reuse known resources, workloads, affected operations, probes and acceptance conditions. Unsupported suggestions are discarded. LLM access is not necessary for matching or classifying controller evidence.

## Audit decisions

- **Confirmed interference**: baseline passed, updated failed, and attributable resource evidence supports the SRG path.
- **Regression, mechanism unresolved**: a matched regression exists without sufficient attribution evidence.
- **Not reproduced**: both baseline and updated pass the recorded preservation condition.
- **Unsupported**: missing or failed baseline, absent updated observations, or otherwise noncomparable evidence.

Successful reversal is recorded as stronger supporting evidence, not required for a regression to be observed. Neither resource sharing alone nor metric growth alone is classified as a failure.

## Implementation boundaries

This repository implements graph construction, dependency closure, change reconciliation, test qualification and deduplication, optional LLM generation, matched evidence analysis, outcome tiers, JSON reports, read-only probes, and deterministic tests. It does **not** claim to intercept proprietary firmware internals or control Siemens/PLCnext engineering downloads without vendor-specific integrations. See `docs/IMPLEMENTATION_SCOPE.md` for the supported boundaries and `docs/PAPER_MAPPING.md` for section-level traceability.

**Matched-run evidence:** Raw `collect` output deliberately has no trusted `context`. A staging-test operator must set an identical verified `RunContext` on baseline and updated snapshots before an audit can conclude a regression or a negative result. The auditor rejects observations without matched state, input trace, unaffected-service workload, observation window, persistence state, and oracle version.
