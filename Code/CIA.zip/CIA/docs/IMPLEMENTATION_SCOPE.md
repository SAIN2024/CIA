# Supported execution boundary

The library is a deployable C# auditing engine. It accepts accessible engineering artifacts already normalized to the documented JSON deployment schema and imported runtime observations. The CLI does not modify PLC programs, reset controllers, modify TIA Portal projects, or administer PLCnext runtime services.

`collect` supports read-only HTTP GET, TCP connectivity, local file existence, local file status, and JSON metric checks. For potentially state-changing tests such as logging saturation, restarting PLC services, rollback, file writes, and vendor-specific instrumentation, provide independently collected snapshots from a physically isolated authorized staging controller. The snapshot schema makes these evidence boundaries explicit. Reversal evidence must be from a separately established reset/revert experiment; no automatic reversal is inferred.

Siemens TIA Portal Openness V20/V21 uses separately installed Windows engineering APIs targeting .NET Framework 4.8, and therefore is not directly referenced from the cross-platform .NET 8 project. A production engineering adapter needs Siemens tooling and an authenticated, authorized Windows environment. PLCnext instrumentation similarly depends on supported controller access, engineering runtime configuration and exposed diagnostics.

Importing a measurement is distinct from proving it: the data source and provenance should be independently checked. Resource corroboration records are provided through the snapshot; the engine requires `consistent=true`, `attributed=true`, and matching resource identity to classify the finding as corroborated. No arbitrary API snapshot is treated as a proven causal mechanism, and absence of resource evidence leaves attribution unresolved.

No full physical-controller end-to-end integration tests were performed in this environment. The supplied fixtures demonstrate report formats, not the paper's empirical detection counts.

Matched-execution contexts are mandatory for a positive or negative comparison. `ValidationSnapshot.context` records the identical initial-state ID, external-input trace hash, unaffected-service workload hash, observation window, persistent-state identifier, and acceptance-oracle version. The independent staging harness must populate these identifiers truthfully. `collect` produces unqualified raw probes; they are not by themselves sufficient for an attributed audit decision.
