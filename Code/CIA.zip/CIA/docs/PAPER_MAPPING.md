# Paper-to-code traceability

| Latest manuscript section | C# code | Notes |
|---|---|---|
| 3.1 Preservation objective, candidate obligations | `GraphAndImpact.cs`, `Contracts.cs` | Baseline acceptance and operation/workload scoping |
| 3.2 Service–Resource Graph construction | `ServiceResourceGraph` | Identified resources and pools, operation-labeled edges, evidence provenance |
| 3.2 Config/runtime profiling | `Deployment`, `Dependency`, `Observation` | Inputs are imported observations, not universal firmware interception |
| 3.3 Change impact and artifact reconciliation | `ImpactAnalyzer` | Updated/old dependency comparison; explicit resource impact also supported |
| 3.4 SRG-guided test generation | `TestGenerator`, `LlmTestSuggester` | Grounding, filtering, deduplication, operator overrides |
| 3.5 Matched execution | `ProbeExecutor`, `ValidationSnapshot`, `AuditValidator` | Read-only probe collection or staging snapshots |
| 3.5 Resource corroboration/reversal | `AuditValidator` | Independent evidence and optional restoration observation |
| 3.6 Audit outcomes | `Finding`, `AuditReport` | Four dispositions, separate evidence levels |
| 4 Evaluation | `tests/Cia.Tests`, `examples` | Tests are functional fixtures, not a reproduction of the 30 published scenarios |

The design follows the manuscript's four-stage CIA architecture; it intentionally does not continue the superseded policy-synthesis/runtime-blocking workflow in the uploaded archive.
