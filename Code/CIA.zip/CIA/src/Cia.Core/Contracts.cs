using System.Text.Json;
using System.Text.Json.Serialization;

namespace Cia.Core;

public static class JsonFiles
{
    public static readonly JsonSerializerOptions Options = new()
    {
        PropertyNameCaseInsensitive = true, PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = true, Converters = { new JsonStringEnumConverter(JsonNamingPolicy.CamelCase) }
    };
    public static T Read<T>(string path) where T : class =>
        JsonSerializer.Deserialize<T>(File.ReadAllText(path), Options) ?? throw new InvalidDataException($"Invalid JSON: {path}");
    public static void Write<T>(string path, T value)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))!);
        File.WriteAllText(path, JsonSerializer.Serialize(value, Options));
    }
}

public enum ResourceKind { Identity, Pool }
public enum EvidenceSource { Configuration, Runtime, PoolCorrelation }
public enum Outcome { ConfirmedInterference, RegressionUnresolved, NotReproduced, Unsupported }
public enum ProbeType { Http, Tcp, FileExists, MetricThreshold, JsonField, StatusEquals }

public sealed record Resource(string Id, ResourceKind Kind, string Scope, string Category, string? ParentPool = null);
public sealed record Service(string Id, string Platform, string? Description = null);
public sealed record Dependency(string ServiceId, string ResourceId, string OperationId, EvidenceSource Source, string Evidence, string? Timestamp = null, double? AccessFrequency = null);
public sealed record Acceptance(string Id, string ServiceId, string OperationId, string WorkloadId, string ProbeId, string Condition, string? Description = null);
public sealed record Probe(string Id, ProbeType Type, string Target, string? Expected = null, double? Minimum = null, double? Maximum = null, int TimeoutMs = 5000);
public sealed record Workload(string Id, string? Description = null, int DurationSeconds = 0, Dictionary<string, string>? Parameters = null);
public sealed record Change(string Id, string ServiceId, string Description, string? ArtifactPath = null, List<string>? ExplicitResources = null);
public sealed record Observation(string DeploymentId, string ServiceId, string OperationId, string WorkloadId,
    string ProbeId, bool? Passed, string? Value, DateTimeOffset Timestamp, string? Error = null,
    Dictionary<string, double>? Metrics = null);
public sealed record Evidence(string TestId, string ResourceId, EvidenceSource Source, string Description, bool Consistent, bool Attributed);
public sealed record RunContext(string InitialStateId, string InputTraceHash, string UnaffectedWorkloadHash,
    int ObservationWindowMs, string PersistentStateId, string AcceptanceVersion);
public sealed record ValidationSnapshot(string DeploymentId, List<Observation> Observations, List<Evidence> Evidence,
    RunContext? Context = null);
public sealed record TestSpec(string Id, string ChangeId, string AffectedService, string OperationId,
    string ResourceId, string WorkloadId, string ProbeId, string Condition, string Reason,
    bool CandidateFromLlm = false);
public sealed record Finding(string TestId, Outcome Outcome, string AffectedService, string OperationId,
    string WorkloadId, string ResourceId, bool BaselinePassed, bool UpdatedPassed,
    bool ResourceCorroborated, bool? ReversalRestored, string Explanation,
    IReadOnlyList<Evidence> Evidence);
public sealed record AuditReport(string RunId, DateTimeOffset GeneratedAt, string BaselineDeployment,
    string UpdatedDeployment, IReadOnlyList<Change> Changes, int ServiceCount, int ResourceCount,
    int EdgeCount, IReadOnlyList<TestSpec> Tests, IReadOnlyList<Finding> Findings,
    IReadOnlyList<string> Warnings, Dictionary<string, int> Summary);

public sealed class Deployment
{
    public string Id { get; set; } = "";
    public string Platform { get; set; } = "";
    public List<Service> Services { get; set; } = [];
    public List<Resource> Resources { get; set; } = [];
    public List<Dependency> Dependencies { get; set; } = [];
    public List<Acceptance> Acceptances { get; set; } = [];
    public List<Probe> Probes { get; set; } = [];
    public List<Workload> Workloads { get; set; } = [];
    public Dictionary<string, string> ArtifactChecksums { get; set; } = [];
}

public sealed class AuditInput
{
    public Deployment Baseline { get; set; } = new();
    public Deployment Updated { get; set; } = new();
    public List<Change> Changes { get; set; } = [];
    public ValidationSnapshot? BaselineSnapshot { get; set; }
    public ValidationSnapshot? UpdatedSnapshot { get; set; }
    public ValidationSnapshot? ReversalSnapshot { get; set; }
    public List<TestSpec> OperatorTests { get; set; } = [];
}
