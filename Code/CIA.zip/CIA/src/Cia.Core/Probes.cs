using System.Net.Sockets;
using System.Net.Http;
using System.Text.Json;

namespace Cia.Core;

public static class ProbeExecutor
{
    public static async Task<Observation> RunAsync(string deploymentId, Acceptance acceptance,
        Probe probe, CancellationToken ct = default)
    {
        bool passed = false;
        string? value = null;
        string? error = null;
        try
        {
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
            timeout.CancelAfter(TimeSpan.FromMilliseconds(Math.Clamp(probe.TimeoutMs, 100, 120_000)));
            switch (probe.Type)
            {
                case ProbeType.Http:
                {
                    using var client = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false });
                    using var response = await client.GetAsync(probe.Target, timeout.Token);
                    value = ((int)response.StatusCode).ToString(System.Globalization.CultureInfo.InvariantCulture);
                    passed = probe.Expected is null ? response.IsSuccessStatusCode : value == probe.Expected;
                    break;
                }
                case ProbeType.Tcp:
                {
                    var parts = probe.Target.Split(':', 2);
                    if (parts.Length != 2 || !int.TryParse(parts[1], out var port))
                        throw new InvalidDataException("TCP target must be host:port.");
                    using var tcp = new TcpClient();
                    await tcp.ConnectAsync(parts[0], port, timeout.Token);
                    passed = tcp.Connected;
                    value = passed ? "connected" : "disconnected";
                    break;
                }
                case ProbeType.FileExists:
                    passed = File.Exists(probe.Target);
                    value = passed ? "exists" : "missing";
                    break;
                case ProbeType.StatusEquals:
                    value = File.ReadAllText(probe.Target).Trim();
                    passed = value == probe.Expected;
                    break;
                case ProbeType.JsonField:
                case ProbeType.MetricThreshold:
                {
                    using var document = JsonDocument.Parse(await File.ReadAllTextAsync(probe.Target, timeout.Token));
                    var root = document.RootElement;
                    if (string.IsNullOrWhiteSpace(probe.Expected))
                        throw new InvalidDataException("JSON probe requires expected dotted field path for extraction.");
                    foreach (var key in probe.Expected.Split('.')) root = root.GetProperty(key);
                    value = root.ToString();
                    if (probe.Type == ProbeType.JsonField) passed = !string.IsNullOrEmpty(value);
                    else
                    {
                        var numeric = root.GetDouble();
                        passed = (probe.Minimum is null || numeric >= probe.Minimum) &&
                                 (probe.Maximum is null || numeric <= probe.Maximum);
                    }
                    break;
                }
                default: throw new NotSupportedException($"Unsupported probe type: {probe.Type}");
            }
        }
        catch (Exception ex) when (ex is IOException or HttpRequestException or SocketException or
                                   OperationCanceledException or InvalidDataException or JsonException or
                                   NotSupportedException or ArgumentException)
        {
            error = ex.Message;
        }
        return new Observation(deploymentId, acceptance.ServiceId, acceptance.OperationId,
            acceptance.WorkloadId, acceptance.ProbeId, passed, value, DateTimeOffset.UtcNow, error);
    }
    public static async Task<ValidationSnapshot> CollectAsync(Deployment deployment, CancellationToken ct = default)
    {
        new ServiceResourceGraph(deployment).Validate();
        var observations = new List<Observation>();
        foreach (var acceptance in deployment.Acceptances)
        {
            var probe = deployment.Probes.Single(p => p.Id == acceptance.ProbeId);
            observations.Add(await RunAsync(deployment.Id, acceptance, probe, ct));
        }
        return new ValidationSnapshot(deployment.Id, observations, []);
    }
}
