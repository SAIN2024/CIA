namespace Cia.Core;

public sealed class ServiceResourceGraph
{
    public Deployment Deployment { get; }
    private readonly Dictionary<string, Resource> _resources;
    private readonly Dictionary<string, List<Dependency>> _serviceEdges;
    public ServiceResourceGraph(Deployment deployment)
    {
        Deployment = deployment;
        _resources = deployment.Resources.ToDictionary(r => r.Id, StringComparer.Ordinal);
        _serviceEdges = deployment.Dependencies.GroupBy(e => e.ServiceId, StringComparer.Ordinal)
            .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.Ordinal);
    }
    public IReadOnlyList<Dependency> EdgesFor(string serviceId, string operationId) =>
        _serviceEdges.TryGetValue(serviceId, out var edges)
            ? edges.Where(e => e.OperationId == operationId).ToList() : [];
    public IEnumerable<string> ResourceClosure(string resourceId)
    {
        var visited = new HashSet<string>(StringComparer.Ordinal);
        var current = resourceId;
        while (visited.Add(current))
        {
            yield return current;
            if (!_resources.TryGetValue(current, out var r) || string.IsNullOrWhiteSpace(r.ParentPool)) break;
            current = r.ParentPool;
        }
    }
    public HashSet<string> DependenciesFor(string service, string operation) =>
        EdgesFor(service, operation).SelectMany(e => ResourceClosure(e.ResourceId)).ToHashSet(StringComparer.Ordinal);

    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(Deployment.Id)) throw new InvalidDataException("Deployment id required.");
        EnsureUnique(Deployment.Services.Select(x => x.Id), "service");
        EnsureUnique(Deployment.Resources.Select(x => x.Id), "resource");
        EnsureUnique(Deployment.Probes.Select(x => x.Id), "probe");
        EnsureUnique(Deployment.Workloads.Select(x => x.Id), "workload");
        EnsureUnique(Deployment.Acceptances.Select(x => x.Id), "acceptance");
        var services = Deployment.Services.Select(x => x.Id).ToHashSet(StringComparer.Ordinal);
        var probes = Deployment.Probes.Select(x => x.Id).ToHashSet(StringComparer.Ordinal);
        var workloads = Deployment.Workloads.Select(x => x.Id).ToHashSet(StringComparer.Ordinal);
        foreach (var resource in Deployment.Resources)
        {
            if (!string.IsNullOrEmpty(resource.ParentPool) && !_resources.ContainsKey(resource.ParentPool))
                throw new InvalidDataException($"Unknown pool {resource.ParentPool}");
            var seen = new HashSet<string>(StringComparer.Ordinal);
            var current = resource.Id;
            while (true)
            {
                if (!seen.Add(current)) throw new InvalidDataException($"Resource parent cycle at {current}.");
                if (!_resources.TryGetValue(current, out var item) || string.IsNullOrWhiteSpace(item.ParentPool)) break;
                current = item.ParentPool;
            }
        }
        foreach (var dep in Deployment.Dependencies)
        {
            if (!services.Contains(dep.ServiceId) || !_resources.ContainsKey(dep.ResourceId))
                throw new InvalidDataException($"Invalid dependency {dep.ServiceId}/{dep.ResourceId}");
        }
        foreach (var acceptance in Deployment.Acceptances)
        {
            if (!services.Contains(acceptance.ServiceId) || !probes.Contains(acceptance.ProbeId) || !workloads.Contains(acceptance.WorkloadId))
                throw new InvalidDataException($"Invalid acceptance {acceptance.Id}");
        }
    }
    private static void EnsureUnique(IEnumerable<string> ids, string kind)
    {
        var set = new HashSet<string>(StringComparer.Ordinal);
        foreach (var id in ids)
            if (string.IsNullOrWhiteSpace(id) || !set.Add(id)) throw new InvalidDataException($"Missing or duplicate {kind}: {id}");
    }
}

public sealed record ChangeImpact(Change Change, IReadOnlySet<string> ImpactResources,
    IReadOnlyList<(Acceptance Acceptance, string SharedResource)> Affected);

public static class ImpactAnalyzer
{
    public static List<ChangeImpact> Analyze(ServiceResourceGraph baseline, ServiceResourceGraph updated,
        IReadOnlyList<Change> changes)
    {
        var result = new List<ChangeImpact>();
        foreach (var change in changes)
        {
            var affectedResources = new HashSet<string>(StringComparer.Ordinal);
            if (change.ExplicitResources is not null)
                foreach (var id in change.ExplicitResources) affectedResources.UnionWith(updated.ResourceClosure(id));
            var oldEdges = baseline.Deployment.Dependencies.Where(e => e.ServiceId == change.ServiceId).ToList();
            var newEdges = updated.Deployment.Dependencies.Where(e => e.ServiceId == change.ServiceId).ToList();
            foreach (var dep in newEdges)
            {
                var existing = oldEdges.Any(e => e.ResourceId == dep.ResourceId && e.OperationId == dep.OperationId);
                if (!existing) affectedResources.UnionWith(updated.ResourceClosure(dep.ResourceId));
            }
            foreach (var dep in oldEdges)
            {
                var existing = newEdges.Any(e => e.ResourceId == dep.ResourceId && e.OperationId == dep.OperationId);
                if (!existing) affectedResources.UnionWith(baseline.ResourceClosure(dep.ResourceId));
            }
            // The update may alter demand without altering a named dependency.
            foreach (var dep in newEdges) affectedResources.UnionWith(updated.ResourceClosure(dep.ResourceId));
            foreach (var dep in oldEdges) affectedResources.UnionWith(baseline.ResourceClosure(dep.ResourceId));
            var affected = new List<(Acceptance, string)>();
            foreach (var acceptance in baseline.Deployment.Acceptances)
            {
                var shared = baseline.DependenciesFor(acceptance.ServiceId, acceptance.OperationId)
                    .Intersect(affectedResources, StringComparer.Ordinal).OrderBy(x => x, StringComparer.Ordinal).FirstOrDefault();
                if (shared is not null) affected.Add((acceptance, shared));
            }
            result.Add(new ChangeImpact(change, affectedResources, affected));
        }
        return result;
    }
}
