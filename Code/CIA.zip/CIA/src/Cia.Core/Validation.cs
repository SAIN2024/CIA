namespace Cia.Core;

public static class AuditValidator
{
    public static Finding Validate(TestSpec test, ValidationSnapshot? baseline,
        ValidationSnapshot? updated, ValidationSnapshot? reversal)
    {
        var before = Find(baseline, test);
        var after = Find(updated, test);
        if (baseline?.Context is null || updated?.Context is null || baseline.Context != updated.Context)
            return new Finding(test.Id, Outcome.Unsupported, test.AffectedService, test.OperationId,
                test.WorkloadId, test.ResourceId, false, false, false, null,
                "Matched run context absent or different (initial state, inputs, unaffected workloads, window, persistence, or oracle).", []);
        if (before?.Passed != true || after?.Passed is null)
            return new Finding(test.Id, Outcome.Unsupported, test.AffectedService, test.OperationId,
                test.WorkloadId, test.ResourceId, before?.Passed == true, after?.Passed == true,
                false, null, "Required matched baseline and updated observations are missing or baseline failed.", []);
        if (after.Passed == true)
            return new Finding(test.Id, Outcome.NotReproduced, test.AffectedService, test.OperationId,
                test.WorkloadId, test.ResourceId, true, true, false, null,
                "The preserved operation passed in both deployments under the recorded workload.", []);
        var evidence = updated!.Evidence.Where(e => e.TestId == test.Id && e.Consistent).ToList();
        var corroborated = evidence.Any(e => e.Attributed && e.ResourceId == test.ResourceId);
        var rolledBack = Find(reversal, test);
        bool? restored = rolledBack?.Passed;
        var outcome = corroborated ? Outcome.ConfirmedInterference : Outcome.RegressionUnresolved;
        var explanation = corroborated
            ? "Matched regression with supported and attributed resource-dependency evidence."
            : "Matched regression; evidence is insufficient to attribute a specific resource mechanism.";
        if (restored == true) explanation += " The operation recovered in the controlled reversal.";
        else if (restored == false) explanation += " The recorded reversal did not restore the operation.";
        return new Finding(test.Id, outcome, test.AffectedService, test.OperationId, test.WorkloadId,
            test.ResourceId, true, false, corroborated, restored, explanation, evidence);
    }
    private static Observation? Find(ValidationSnapshot? snapshot, TestSpec test)
    {
        if (snapshot is null) return null;
        return snapshot.Observations
            .Where(o => o.ServiceId == test.AffectedService && o.OperationId == test.OperationId &&
                        o.WorkloadId == test.WorkloadId && o.ProbeId == test.ProbeId &&
                        o.DeploymentId == snapshot.DeploymentId)
            .OrderByDescending(o => o.Timestamp).FirstOrDefault();
    }
}

public static class Auditor
{
    public static async Task<AuditReport> RunAsync(AuditInput input,
        LlmTestSuggester? llm = null, CancellationToken cancellationToken = default)
    {
        var baseline = new ServiceResourceGraph(input.Baseline);
        var updated = new ServiceResourceGraph(input.Updated);
        baseline.Validate(); updated.Validate();
        if (input.Baseline.Id == input.Updated.Id)
            throw new InvalidDataException("Baseline and updated deployment IDs must differ.");
        if (input.Changes.Count == 0) throw new InvalidDataException("At least one implemented change is required.");
        if (input.Changes.Select(x => x.Id).Distinct(StringComparer.Ordinal).Count() != input.Changes.Count)
            throw new InvalidDataException("Change IDs must be unique.");
        if (input.Changes.Any(c => !input.Baseline.Services.Any(s => s.Id == c.ServiceId) &&
                                   !input.Updated.Services.Any(s => s.Id == c.ServiceId)))
            throw new InvalidDataException("Changed service absent from both deployments.");
        var impacts = ImpactAnalyzer.Analyze(baseline, updated, input.Changes);
        var approvedOperatorTests = input.OperatorTests.Where(t =>
            impacts.Any(i => i.Change.Id == t.ChangeId) &&
            input.Baseline.Acceptances.Any(a => a.ServiceId == t.AffectedService &&
                a.OperationId == t.OperationId && a.WorkloadId == t.WorkloadId &&
                a.ProbeId == t.ProbeId && a.Condition == t.Condition) &&
            input.Baseline.Resources.Any(r => r.Id == t.ResourceId)).ToList();
        var tests = TestGenerator.Generate(impacts, approvedOperatorTests);
        var warnings = new List<string>();
        if (llm is not null)
        {
            try
            {
                var suggestions = await llm.SuggestAsync(impacts, input.Baseline, input.Updated, cancellationToken);
                tests = TestGenerator.Deduplicate(tests.Concat(suggestions));
            }
            catch (Exception ex) when (ex is HttpRequestException or System.Text.Json.JsonException or InvalidOperationException)
            {
                warnings.Add($"LLM suggestion unavailable: {ex.Message}; deterministic preservation tests retained.");
            }
        }
        if (input.BaselineSnapshot?.DeploymentId != input.Baseline.Id || input.UpdatedSnapshot?.DeploymentId != input.Updated.Id)
            warnings.Add("Missing or mismatched snapshots: tests without valid matched observations will be unsupported.");
        if (input.BaselineSnapshot is not null && input.BaselineSnapshot.DeploymentId != input.Baseline.Id)
            throw new InvalidDataException("Baseline snapshot deployment does not match baseline artifact.");
        if (input.UpdatedSnapshot is not null && input.UpdatedSnapshot.DeploymentId != input.Updated.Id)
            throw new InvalidDataException("Updated snapshot deployment does not match updated artifact.");
        if (tests.Count == 0) warnings.Add("No supported preservation obligations found; absence of tests is not proof of compatibility.");
        var findings = tests.Select(t => AuditValidator.Validate(t, input.BaselineSnapshot,
            input.UpdatedSnapshot, input.ReversalSnapshot)).ToList();
        var summary = new Dictionary<string, int>
        {
            ["tests"] = tests.Count,
            ["regressions"] = findings.Count(f => f.Outcome is Outcome.ConfirmedInterference or Outcome.RegressionUnresolved),
            ["corroborated"] = findings.Count(f => f.ResourceCorroborated),
            ["reversalSupported"] = findings.Count(f => f.ReversalRestored == true && f.ResourceCorroborated),
            ["unresolvedRegressions"] = findings.Count(f => f.Outcome == Outcome.RegressionUnresolved),
            ["notReproduced"] = findings.Count(f => f.Outcome == Outcome.NotReproduced),
            ["unsupported"] = findings.Count(f => f.Outcome == Outcome.Unsupported),
            ["unchangedServiceRegressions"] = findings.Count(f =>
                (f.Outcome is Outcome.ConfirmedInterference or Outcome.RegressionUnresolved) &&
                input.Changes.All(c => c.ServiceId != f.AffectedService))
        };
        if (findings.All(f => f.Outcome == Outcome.NotReproduced))
            warnings.Add("No regression reproduced for exercised conditions; no claim of comprehensive compatibility is made.");
        return new AuditReport(Guid.NewGuid().ToString("N"), DateTimeOffset.UtcNow, input.Baseline.Id,
            input.Updated.Id, input.Changes, input.Baseline.Services.Count,
            input.Baseline.Resources.Count, input.Baseline.Dependencies.Count,
            tests, findings, warnings, summary);
    }
}
