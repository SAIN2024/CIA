using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace Cia.Core;

public static class TestGenerator
{
    public static List<TestSpec> Generate(IReadOnlyList<ChangeImpact> impacts, IEnumerable<TestSpec>? operatorTests = null)
    {
        var tests = new List<TestSpec>();
        foreach (var impact in impacts)
        foreach (var (acceptance, shared) in impact.Affected)
        {
            tests.Add(new TestSpec($"{impact.Change.Id}:{acceptance.Id}:{shared}", impact.Change.Id,
                acceptance.ServiceId, acceptance.OperationId, shared, acceptance.WorkloadId, acceptance.ProbeId,
                acceptance.Condition, $"Preserve baseline operation via resource {shared}"));
        }
        if (operatorTests is not null) tests.AddRange(operatorTests);
        return Deduplicate(tests);
    }
    public static List<TestSpec> Deduplicate(IEnumerable<TestSpec> specs) => specs
        .GroupBy(t => (t.ChangeId, t.AffectedService, t.OperationId, t.ResourceId, t.WorkloadId, t.ProbeId, t.Condition))
        .Select(g => g.First()).OrderBy(x => x.Id, StringComparer.Ordinal).ToList();
    public static List<TestSpec> ValidateGenerated(IEnumerable<TestSpec> proposed,
        IReadOnlyList<ChangeImpact> impacts, Deployment baseline, Deployment updated)
    {
        var changes = impacts.ToDictionary(x => x.Change.Id, StringComparer.Ordinal);
        var approvals = baseline.Acceptances.ToHashSet();
        var probes = baseline.Probes.Select(x => x.Id).ToHashSet(StringComparer.Ordinal);
        var workloads = baseline.Workloads.Select(x => x.Id).ToHashSet(StringComparer.Ordinal);
        var output = new List<TestSpec>();
        foreach (var candidate in proposed)
        {
            if (!changes.TryGetValue(candidate.ChangeId, out var impact)) continue;
            if (!probes.Contains(candidate.ProbeId) || !workloads.Contains(candidate.WorkloadId)) continue;
            var acceptance = approvals.FirstOrDefault(a => a.ServiceId == candidate.AffectedService && a.OperationId == candidate.OperationId && a.WorkloadId == candidate.WorkloadId && a.ProbeId == candidate.ProbeId && a.Condition == candidate.Condition);
            if (acceptance is null) continue;
            if (!impact.ImpactResources.Contains(candidate.ResourceId)) continue;
            var baselineGraph = new ServiceResourceGraph(baseline);
            if (!baselineGraph.DependenciesFor(candidate.AffectedService, candidate.OperationId).Contains(candidate.ResourceId)) continue;
            if (!updated.Services.Any(s => s.Id == candidate.AffectedService) && !baseline.Services.Any(s => s.Id == candidate.AffectedService)) continue;
            output.Add(candidate with { CandidateFromLlm = true });
        }
        return Deduplicate(output);
    }
}

public sealed class LlmTestSuggester(HttpClient http, string endpoint, string model, string apiKey)
{
    public async Task<List<TestSpec>> SuggestAsync(IReadOnlyList<ChangeImpact> impacts,
        Deployment baseline, Deployment updated, CancellationToken ct = default)
    {
        var payload = new
        {
            model,
            temperature = 0,
            messages = new object[]
            {
                new { role = "system", content = "Return strictly valid JSON containing a single property tests: array of TestSpec objects. Suggest ONLY already-authorized baseline acceptance conditions, known probes, known workloads, and resource paths in the change impact. Never invent endpoints, hardware commands, or acceptance oracles. Do not treat inferred dependencies as proof of regression." },
                new { role = "user", content = JsonSerializer.Serialize(new {
                    impacts = impacts.Select(i => new { i.Change, resources = i.ImpactResources,
                        affected = i.Affected.Select(a => new { a.Acceptance, a.SharedResource }) }),
                    baseline.Acceptances, baseline.Probes, baseline.Workloads,
                    baselineDependencies = baseline.Dependencies, baseline.Resources,
                    updatedDependencies = updated.Dependencies
                }, JsonFiles.Options) }
            }
        };
        using var req = new HttpRequestMessage(HttpMethod.Post, endpoint);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);
        req.Content = new StringContent(JsonSerializer.Serialize(payload, JsonFiles.Options), Encoding.UTF8, "application/json");
        using var res = await http.SendAsync(req, ct);
        res.EnsureSuccessStatusCode();
        using var document = JsonDocument.Parse(await res.Content.ReadAsStringAsync(ct));
        var content = document.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString() ?? "";
        content = content.Trim();
        if (content.StartsWith("```", StringComparison.Ordinal))
        {
            var firstNewline = content.IndexOf('\n');
            var lastFence = content.LastIndexOf("```", StringComparison.Ordinal);
            if (firstNewline < 0 || lastFence <= firstNewline) return [];
            content = content[(firstNewline + 1)..lastFence].Trim();
        }
        using var parsed = JsonDocument.Parse(content);
        var tests = parsed.RootElement.GetProperty("tests").Deserialize<List<TestSpec>>(JsonFiles.Options) ?? [];
        return TestGenerator.ValidateGenerated(tests, impacts, baseline, updated);
    }
}
