using Cia.Core;

static void Usage()
{
    Console.WriteLine("CIA — Cross-Service Interference Auditor");
    Console.WriteLine("  cia audit <audit-input.json> <report.json> [--llm]");
    Console.WriteLine("  cia collect <deployment.json> <snapshot.json>");
    Console.WriteLine("  cia inspect <deployment.json>");
    Console.WriteLine("  cia help");
    Console.WriteLine("LLM optional: CIA_LLM_ENDPOINT (full chat-completions URL), CIA_LLM_MODEL, CIA_LLM_API_KEY");
}
try
{
    if (args.Length == 0 || args[0] == "help") { Usage(); return; }
    if (args[0] == "inspect" && args.Length == 2)
    {
        var deployment = JsonFiles.Read<Deployment>(args[1]);
        new ServiceResourceGraph(deployment).Validate();
        Console.WriteLine($"{deployment.Id}: {deployment.Services.Count} services, {deployment.Resources.Count} resources, {deployment.Dependencies.Count} dependencies, {deployment.Acceptances.Count} obligations");
        return;
    }
    if (args[0] == "collect" && args.Length == 3)
    {
        var deployment = JsonFiles.Read<Deployment>(args[1]);
        var snapshot = await ProbeExecutor.CollectAsync(deployment);
        JsonFiles.Write(args[2], snapshot);
        Console.WriteLine($"Recorded {snapshot.Observations.Count} read-only probe observations in {args[2]}");
        return;
    }
    if (args[0] == "audit" && (args.Length == 3 || (args.Length == 4 && args[3] == "--llm")))
    {
        var input = JsonFiles.Read<AuditInput>(args[1]);
        LlmTestSuggester? llm = null;
        if (args.Length == 4)
        {
            var endpoint = Environment.GetEnvironmentVariable("CIA_LLM_ENDPOINT");
            var model = Environment.GetEnvironmentVariable("CIA_LLM_MODEL");
            var key = Environment.GetEnvironmentVariable("CIA_LLM_API_KEY");
            if (string.IsNullOrWhiteSpace(endpoint) || string.IsNullOrWhiteSpace(model) || string.IsNullOrWhiteSpace(key))
                throw new InvalidOperationException("CIA_LLM_ENDPOINT, CIA_LLM_MODEL, and CIA_LLM_API_KEY required for --llm.");
            llm = new LlmTestSuggester(new HttpClient { Timeout = TimeSpan.FromSeconds(90) }, endpoint, model, key);
        }
        var report = await Auditor.RunAsync(input, llm);
        JsonFiles.Write(args[2], report);
        foreach (var (metric, value) in report.Summary) Console.WriteLine($"{metric}: {value}");
        foreach (var warning in report.Warnings) Console.Error.WriteLine($"NOTE: {warning}");
        Console.WriteLine($"Report: {args[2]}");
        return;
    }
    Usage(); Environment.ExitCode = 2;
}
catch (Exception ex)
{
    Console.Error.WriteLine($"CIA: {ex.Message}");
    Environment.ExitCode = 1;
}
