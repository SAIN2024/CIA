using System.Collections.Generic;
using CiaRuntime.Models;

namespace CiaRuntime.Policies
{
    public sealed class PolicyRule
    {
        public string ServiceName { get; }
        public string ResourcePattern { get; }
        public ResourceType ResourceType { get; }
        public IReadOnlyCollection<OperationType> AllowedOperations { get; }
        public double MaxQuantity { get; }

        public PolicyRule(
            string serviceName,
            string resourcePattern,
            ResourceType resourceType,
            IReadOnlyCollection<OperationType> allowedOperations,
            double maxQuantity)
        {
            ServiceName = serviceName;
            ResourcePattern = resourcePattern;
            ResourceType = resourceType;
            AllowedOperations = allowedOperations;
            MaxQuantity = maxQuantity;
        }
    }
}
