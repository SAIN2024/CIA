using System;
using System.Collections.Generic;
using System.Linq;
using CiaRuntime.Models;

namespace CiaRuntime.Policies
{
    public sealed class PolicySet
    {
        private readonly List<PolicyRule> _rules;

        public IReadOnlyList<PolicyRule> Rules => _rules;

        public PolicySet(IEnumerable<PolicyRule> rules)
        {
            _rules = rules.ToList();
        }

        public PolicyRule? FindRule(ResourceEvent ev)
        {
            PolicyRule? best = null;

            foreach (var rule in _rules)
            {
                if (!string.Equals(rule.ServiceName, ev.ServiceName, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                if (rule.ResourceType != ev.ResourceType)
                {
                    continue;
                }

                if (!ResourceIdMatches(rule.ResourcePattern, ev.ResourceId))
                {
                    continue;
                }

                // prefer more specific patterns (longer literal portion)
                if (best == null || rule.ResourcePattern.Length > best.ResourcePattern.Length)
                {
                    best = rule;
                }
            }

            return best;
        }

        private static bool ResourceIdMatches(string pattern, string value)
        {
            if (string.IsNullOrEmpty(pattern))
            {
                return false;
            }

            if (pattern == "*")
            {
                return true;
            }

            if (pattern.EndsWith("*", StringComparison.Ordinal))
            {
                var prefix = pattern.Substring(0, pattern.Length - 1);
                return value.StartsWith(prefix, StringComparison.OrdinalIgnoreCase);
            }

            return string.Equals(pattern, value, StringComparison.OrdinalIgnoreCase);
        }
    }
}
