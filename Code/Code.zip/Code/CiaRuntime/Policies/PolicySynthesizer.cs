using System;
using System.Collections.Generic;
using System.Linq;
using CiaRuntime.Detection;
using CiaRuntime.Models;

namespace CiaRuntime.Policies
{
    /// <summary>
    /// Builds simple ownership and quota policies from a conflict-free
    /// view of the ServiceResourceGraph.
    /// Conflicting or unbounded edges are excluded from policy synthesis.
    /// </summary>
    public sealed class PolicySynthesizer
    {
        public PolicySet Synthesize(
            ServiceResourceGraph graph,
            IReadOnlyCollection<NamespaceConflict> conflicts,
            IReadOnlyCollection<UnboundedResourceFinding> unbounded)
        {
            var conflictLookup = BuildConflictSet(conflicts);
            var unboundedLookup = BuildUnboundedSet(unbounded);

            var rules = new List<PolicyRule>();

            foreach (var edge in graph.GetEdges())
            {
                if (conflictLookup.Contains((edge.ServiceName, edge.ResourceId)))
                {
                    continue;
                }

                bool isUnbounded =
                    unboundedLookup.Contains((edge.ServiceName, edge.ResourceId));

                var ops = edge.Events
                    .Select(ev => ev.OperationType)
                    .Distinct()
                    .ToList();

                var maxQ = edge.Events.Count > 0
                    ? edge.Events.Max(ev => ev.Quantity)
                    : 0.0;

                double quota = isUnbounded ? -1.0 : maxQ * 1.25;

                var rule = new PolicyRule(
                    edge.ServiceName,
                    edge.ResourceId,
                    edge.ResourceType,
                    ops,
                    quota);

                rules.Add(rule);
            }

            return new PolicySet(rules);
        }

        private static HashSet<(string Service, string Resource)> BuildConflictSet(
            IReadOnlyCollection<NamespaceConflict> conflicts)
        {
            var set = new HashSet<(string, string)>(TupleComparer.OrdinalIgnoreCase);

            foreach (var c in conflicts)
            {
                set.Add((c.ServiceA, c.ResourceId));
                set.Add((c.ServiceB, c.ResourceId));
            }

            return set;
        }

        private static HashSet<(string Service, string Resource)> BuildUnboundedSet(
            IReadOnlyCollection<UnboundedResourceFinding> findings)
        {
            var set = new HashSet<(string, string)>(TupleComparer.OrdinalIgnoreCase);

            foreach (var f in findings)
            {
                set.Add((f.ServiceName, f.ResourceId));
            }

            return set;
        }

        private sealed class TupleComparer : IEqualityComparer<(string, string)>
        {
            public static readonly TupleComparer OrdinalIgnoreCase = new TupleComparer();

            public bool Equals((string, string) x, (string, string) y)
            {
                return string.Equals(x.Item1, y.Item1, StringComparison.OrdinalIgnoreCase) &&
                       string.Equals(x.Item2, y.Item2, StringComparison.OrdinalIgnoreCase);
            }

            public int GetHashCode((string, string) obj)
            {
                var h1 = StringComparer.OrdinalIgnoreCase.GetHashCode(obj.Item1);
                var h2 = StringComparer.OrdinalIgnoreCase.GetHashCode(obj.Item2);
                return HashCode.Combine(h1, h2);
            }
        }
    }
}
