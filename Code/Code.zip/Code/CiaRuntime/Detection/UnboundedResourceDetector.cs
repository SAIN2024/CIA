using System;
using System.Collections.Generic;
using System.Linq;
using CiaRuntime.Models;

namespace CiaRuntime.Detection
{
    public sealed class UnboundedResourceFinding
    {
        public string ServiceName { get; }
        public string ResourceId { get; }
        public ResourceType ResourceType { get; }

        public UnboundedResourceFinding(string serviceName, string resourceId, ResourceType resourceType)
        {
            ServiceName = serviceName;
            ResourceId = resourceId;
            ResourceType = resourceType;
        }
    }

    /// <summary>
    /// Very simple unbounded growth detector.
    /// It looks for monotonically increasing quantities without resets.
    /// Intended as a heuristic for logs, buffers, or memory usage.
    /// </summary>
    public sealed class UnboundedResourceDetector
    {
        public List<UnboundedResourceFinding> DetectUnboundedResources(ServiceResourceGraph graph)
        {
            var findings = new List<UnboundedResourceFinding>();

            foreach (var edge in graph.GetEdges())
            {
                if (!IsGrowthRelevant(edge.ResourceType))
                {
                    continue;
                }

                if (edge.Events.Count < 3)
                {
                    continue;
                }

                var ordered = edge.Events.OrderBy(e => e.Timestamp).ToList();
                double last = ordered[0].Quantity;
                bool everDecrease = false;
                double max = last;

                for (int i = 1; i < ordered.Count; i++)
                {
                    var q = ordered[i].Quantity;
                    if (q < last)
                    {
                        everDecrease = true;
                    }

                    if (q > max)
                    {
                        max = q;
                    }

                    last = q;
                }

                var growth = max - ordered[0].Quantity;
                bool appearsUnbounded = !everDecrease && growth > 10.0;

                if (appearsUnbounded)
                {
                    findings.Add(new UnboundedResourceFinding(
                        edge.ServiceName,
                        edge.ResourceId,
                        edge.ResourceType));
                }
            }

            return findings;
        }

        private static bool IsGrowthRelevant(ResourceType type)
        {
            switch (type)
            {
                case ResourceType.File:
                case ResourceType.Memory:
                case ResourceType.Buffer:
                    return true;
                default:
                    return false;
            }
        }
    }
}
