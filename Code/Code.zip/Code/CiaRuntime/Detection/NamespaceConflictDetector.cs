using System;
using System.Collections.Generic;
using System.Linq;
using CiaRuntime.Models;

namespace CiaRuntime.Detection
{
    public sealed class NamespaceConflict
    {
        public string RuleId { get; }
        public string ServiceA { get; }
        public string ServiceB { get; }
        public string ResourceId { get; }
        public string Description { get; }

        public NamespaceConflict(string ruleId, string serviceA, string serviceB, string resourceId, string description)
        {
            RuleId = ruleId;
            ServiceA = serviceA;
            ServiceB = serviceB;
            ResourceId = resourceId;
            Description = description;
        }
    }

    /// <summary>
    /// Simple name-space conflict detector.
    /// It flags:
    ///   R1: Two services both CREATE the same resource name.
    ///   R2: One service DELETEs a resource another service READs or MODIFYs.
    ///   R3: Services use different resource types with the same identifier.
    ///   R4: Mixed MODIFY patterns (both treat the resource as "owner").
    /// This is intentionally conservative.
    /// </summary>
    public sealed class NamespaceConflictDetector
    {
        public List<NamespaceConflict> DetectConflicts(ServiceResourceGraph graph)
        {
            var conflicts = new List<NamespaceConflict>();

            foreach (var resourceId in graph.Resources)
            {
                var edges = graph.GetEdgesForResource(resourceId).ToList();
                if (edges.Count <= 1)
                {
                    continue;
                }

                // R3: Different resource types on the same identifier.
                var typeGroups = edges
                    .GroupBy(e => e.ResourceType)
                    .ToList();

                if (typeGroups.Count > 1)
                {
                    var allServices = edges.Select(e => e.ServiceName).Distinct().ToList();
                    for (int i = 0; i < allServices.Count; i++)
                    {
                        for (int j = i + 1; j < allServices.Count; j++)
                        {
                            conflicts.Add(new NamespaceConflict(
                                "R3",
                                allServices[i],
                                allServices[j],
                                resourceId,
                                "Services treat the same identifier as different resource types."));
                        }
                    }
                }

                // R1 / R4 / R2
                for (int i = 0; i < edges.Count; i++)
                {
                    for (int j = i + 1; j < edges.Count; j++)
                    {
                        var e1 = edges[i];
                        var e2 = edges[j];

                        if (e1.ServiceName.Equals(e2.ServiceName, StringComparison.OrdinalIgnoreCase))
                        {
                            continue;
                        }

                        var ops1 = e1.Events.Select(ev => ev.OperationType).Distinct().ToList();
                        var ops2 = e2.Events.Select(ev => ev.OperationType).Distinct().ToList();

                        // R1: Both create.
                        if (ops1.Contains(OperationType.Create) && ops2.Contains(OperationType.Create))
                        {
                            conflicts.Add(new NamespaceConflict(
                                "R1",
                                e1.ServiceName,
                                e2.ServiceName,
                                resourceId,
                                "Both services create the same resource name."));
                        }

                        // R4: Both modify, no clear ownership.
                        if (ops1.Contains(OperationType.Modify) && ops2.Contains(OperationType.Modify))
                        {
                            conflicts.Add(new NamespaceConflict(
                                "R4",
                                e1.ServiceName,
                                e2.ServiceName,
                                resourceId,
                                "Both services modify the same resource, ownership ambiguous."));
                        }

                        // R2: One deletes, the other reads or modifies.
                        bool e1Deletes = ops1.Contains(OperationType.Delete);
                        bool e2Deletes = ops2.Contains(OperationType.Delete);
                        bool e1Uses = ops1.Contains(OperationType.Read) || ops1.Contains(OperationType.Modify);
                        bool e2Uses = ops2.Contains(OperationType.Read) || ops2.Contains(OperationType.Modify);

                        if (e1Deletes && e2Uses)
                        {
                            conflicts.Add(new NamespaceConflict(
                                "R2",
                                e1.ServiceName,
                                e2.ServiceName,
                                resourceId,
                                "One service deletes a resource while the other reads or modifies it."));
                        }

                        if (e2Deletes && e1Uses)
                        {
                            conflicts.Add(new NamespaceConflict(
                                "R2",
                                e2.ServiceName,
                                e1.ServiceName,
                                resourceId,
                                "One service deletes a resource while the other reads or modifies it."));
                        }
                    }
                }
            }

            return MergeDuplicates(conflicts);
        }

        private static List<NamespaceConflict> MergeDuplicates(List<NamespaceConflict> conflicts)
        {
            var result = new List<NamespaceConflict>();
            var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var c in conflicts)
            {
                var key = $"{c.RuleId}|{c.ResourceId}|{c.ServiceA}|{c.ServiceB}";
                if (set.Add(key))
                {
                    result.Add(c);
                }
            }

            return result;
        }
    }
}
