namespace CiaRuntime.Models
{
    public enum OperationType
    {
        Create,
        Modify,
        Delete,
        Read
    }
}
