using System;
using System.Collections.Generic;
using System.Linq;

namespace CiaRuntime.Models
{
    /// <summary>
    /// Bipartite graph between services and resources,
    /// storing event sequences on the edges.
    /// </summary>
    public sealed class ServiceResourceGraph
    {
        private readonly Dictionary<(string Service, string Resource), ServiceResourceEdge> _edges;

        public IReadOnlyCollection<string> Services =>
            _edges.Keys.Select(k => k.Service).Distinct().ToList();

        public IReadOnlyCollection<string> Resources =>
            _edges.Keys.Select(k => k.Resource).Distinct().ToList();

        public ServiceResourceGraph()
        {
            _edges = new Dictionary<(string, string), ServiceResourceEdge>(StringTupleComparer.OrdinalIgnoreCase);
        }

        public void AddEvent(ResourceEvent ev)
        {
            var key = (ev.ServiceName, ev.ResourceId);
            if (!_edges.TryGetValue(key, out var edge))
            {
                edge = new ServiceResourceEdge(ev.ServiceName, ev.ResourceId, ev.ResourceType);
                _edges[key] = edge;
            }

            edge.AddEvent(ev);
        }

        public IEnumerable<ServiceResourceEdge> GetEdges()
        {
            return _edges.Values;
        }

        public IEnumerable<ServiceResourceEdge> GetEdgesForResource(string resourceId)
        {
            return _edges.Values.Where(e =>
                e.ResourceId.Equals(resourceId, StringComparison.OrdinalIgnoreCase));
        }

        public IEnumerable<ServiceResourceEdge> GetEdgesForService(string serviceName)
        {
            return _edges.Values.Where(e =>
                e.ServiceName.Equals(serviceName, StringComparison.OrdinalIgnoreCase));
        }

        private sealed class StringTupleComparer : IEqualityComparer<(string, string)>
        {
            public static readonly StringTupleComparer OrdinalIgnoreCase = new StringTupleComparer();

            public bool Equals((string, string) x, (string, string) y)
            {
                return string.Equals(x.Item1, y.Item1, StringComparison.OrdinalIgnoreCase) &&
                       string.Equals(x.Item2, y.Item2, StringComparison.OrdinalIgnoreCase);
            }

            public int GetHashCode((string, string) obj)
            {
                var h1 = StringComparer.OrdinalIgnoreCase.GetHashCode(obj.Item1);
                var h2 = StringComparer.OrdinalIgnoreCase.GetHashCode(obj.Item2);
                return HashCode.Combine(h1, h2);
            }
        }
    }
}
