using System.Collections.Generic;

namespace CiaRuntime.Models
{
    /// <summary>
    /// Capture the time series of interactions between a single
    /// service and a single resource.
    /// </summary>
    public sealed class ServiceResourceEdge
    {
        public string ServiceName { get; }
        public string ResourceId { get; }
        public ResourceType ResourceType { get; }

        public List<ResourceEvent> Events { get; }

        public ServiceResourceEdge(string serviceName, string resourceId, ResourceType resourceType)
        {
            ServiceName = serviceName;
            ResourceId = resourceId;
            ResourceType = resourceType;
            Events = new List<ResourceEvent>();
        }

        public void AddEvent(ResourceEvent ev)
        {
            Events.Add(ev);
        }

        public override string ToString()
        {
            return $"{ServiceName} -> {ResourceType}:{ResourceId} (events={Events.Count})";
        }
    }
}
