using System;

namespace CiaRuntime.Models
{
    /// <summary>
    /// Represents a single resource-affecting event (API call).
    /// </summary>
    public sealed class ResourceEvent
    {
        public string ServiceName { get; }
        public string ResourceId { get; }
        public ResourceType ResourceType { get; }
        public OperationType OperationType { get; }
        public DateTime Timestamp { get; }
        public double Quantity { get; }

        public ResourceEvent(
            string serviceName,
            string resourceId,
            ResourceType resourceType,
            OperationType operationType,
            DateTime timestamp,
            double quantity)
        {
            ServiceName = serviceName;
            ResourceId = resourceId;
            ResourceType = resourceType;
            OperationType = operationType;
            Timestamp = timestamp;
            Quantity = quantity;
        }

        public override string ToString()
        {
            return $"{Timestamp:O} {ServiceName} {OperationType} {ResourceType} {ResourceId} (Q={Quantity:F2})";
        }
    }
}
