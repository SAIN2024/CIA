namespace CiaRuntime.Models
{
    public enum ResourceType
    {
        File,
        DataBlock,
        Socket,
        Memory,
        Buffer,
        Custom
    }
}
