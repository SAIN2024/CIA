using System;
using CiaRuntime.Detection;
using CiaRuntime.Models;
using CiaRuntime.Monitoring;
using CiaRuntime.Policies;
using CiaRuntime.Profiling;

namespace CiaRuntime
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== CIA Runtime Prototype ===");
            Console.WriteLine();

            IRuntimeEventSource eventSource = new VirtualRuntimeEventSource();

            var srg = new ServiceResourceGraph();
            foreach (var ev in eventSource.GetProfilingEvents())
            {
                srg.AddEvent(ev);
            }

            Console.WriteLine("Service–Resource Graph built.");
            Console.WriteLine($"Services: {string.Join(", ", srg.Services)}");
            Console.WriteLine($"Resources: {string.Join(", ", srg.Resources)}");
            Console.WriteLine();

            var nsDetector = new NamespaceConflictDetector();
            var conflicts = nsDetector.DetectConflicts(srg);

            Console.WriteLine("Namespace Conflicts:");
            if (conflicts.Count == 0)
            {
                Console.WriteLine("  None detected.");
            }
            else
            {
                foreach (var c in conflicts)
                {
                    Console.WriteLine($"  [{c.RuleId}] Resource='{c.ResourceId}', S1='{c.ServiceA}', S2='{c.ServiceB}'");
                    if (!string.IsNullOrEmpty(c.Description))
                    {
                        Console.WriteLine($"       {c.Description}");
                    }
                }
            }
            Console.WriteLine();

            var ubDetector = new UnboundedResourceDetector();
            var unbounded = ubDetector.DetectUnboundedResources(srg);

            Console.WriteLine("Unbounded Resource Usage:");
            if (unbounded.Count == 0)
            {
                Console.WriteLine("  None detected.");
            }
            else
            {
                foreach (var u in unbounded)
                {
                    Console.WriteLine($"  Service='{u.ServiceName}', Resource='{u.ResourceId}', Type={u.ResourceType}");
                }
            }
            Console.WriteLine();

            var synthesizer = new PolicySynthesizer();
            var policies = synthesizer.Synthesize(srg, conflicts, unbounded);

            Console.WriteLine("Synthesized Policies:");
            foreach (var p in policies.Rules)
            {
                var ops = string.Join("/", p.AllowedOperations);
                var quotaText = p.MaxQuantity >= 0
                    ? p.MaxQuantity.ToString("F2")
                    : "unbounded";
                Console.WriteLine(
                    $"  Service='{p.ServiceName}', ResourcePattern='{p.ResourcePattern}', " +
                    $"Type={p.ResourceType}, AllowedOps={ops}, Quota={quotaText}");
            }
            Console.WriteLine();

            var monitor = new RuntimeMonitor(policies);

            Console.WriteLine("Monitoring simulated live events:");
            foreach (var liveEvent in eventSource.GetLiveEvents())
            {
                var result = monitor.CheckEvent(liveEvent);
                var status = result.IsAllowed ? "OK" : "BLOCKED";

                Console.WriteLine(
                    $"  [{status}] {liveEvent.Timestamp:HH:mm:ss.fff} " +
                    $"{liveEvent.ServiceName} {liveEvent.OperationType} " +
                    $"{liveEvent.ResourceType} '{liveEvent.ResourceId}' Q={liveEvent.Quantity:F2}");

                if (!result.IsAllowed && !string.IsNullOrWhiteSpace(result.Reason))
                {
                    Console.WriteLine($"       Reason: {result.Reason}");
                }
            }

            Console.WriteLine();
            Console.WriteLine("Done.");
        }
    }
}
