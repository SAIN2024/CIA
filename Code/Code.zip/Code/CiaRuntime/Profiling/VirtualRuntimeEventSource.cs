using System;
using System.Collections.Generic;
using CiaRuntime.Models;

namespace CiaRuntime.Profiling
{
    /// <summary>
    /// Generates a small synthetic trace that exercises the detectors and monitor.
    /// In a real system, this would be replaced by hooks into a PLC runtime.
    /// </summary>
    public sealed class VirtualRuntimeEventSource : IRuntimeEventSource
    {
        public IEnumerable<ResourceEvent> GetProfilingEvents()
        {
            var now = DateTime.UtcNow;

            // ControlService owns DB_Pressure and DB_Temperature.
            yield return new ResourceEvent("ControlService", "DB_Pressure", ResourceType.DataBlock, OperationType.Create, now.AddMilliseconds(0), 10);
            yield return new ResourceEvent("ControlService", "DB_Temperature", ResourceType.DataBlock, OperationType.Create, now.AddMilliseconds(10), 10);
            yield return new ResourceEvent("ControlService", "DB_Pressure", ResourceType.DataBlock, OperationType.Modify, now.AddMilliseconds(20), 1);
            yield return new ResourceEvent("ControlService", "DB_Temperature", ResourceType.DataBlock, OperationType.Modify, now.AddMilliseconds(30), 1);

            // WebService reads DB_Pressure, but also mistakenly creates DB_Status,
            // which ControlService also touches later (name-space conflict).
            yield return new ResourceEvent("WebService", "DB_Pressure", ResourceType.DataBlock, OperationType.Read, now.AddMilliseconds(40), 0);
            yield return new ResourceEvent("WebService", "DB_Status", ResourceType.DataBlock, OperationType.Create, now.AddMilliseconds(50), 5);

            // ControlService modifies DB_Status too.
            yield return new ResourceEvent("ControlService", "DB_Status", ResourceType.DataBlock, OperationType.Modify, now.AddMilliseconds(60), 2);

            // LoggerService appends to runtime.log with monotonically increasing size.
            double size = 1;
            for (int i = 0; i < 6; i++)
            {
                yield return new ResourceEvent(
                    "LoggerService",
                    "log/runtime.log",
                    ResourceType.File,
                    OperationType.Modify,
                    now.AddMilliseconds(100 + i * 10),
                    size);

                size += 5;
            }

            // Another buffer that grows.
            double buf = 2;
            for (int i = 0; i < 5; i++)
            {
                yield return new ResourceEvent(
                    "LoggerService",
                    "buf/hist",
                    ResourceType.Buffer,
                    OperationType.Modify,
                    now.AddMilliseconds(200 + i * 15),
                    buf);

                buf += 3;
            }

            // WebService deletes DB_Status at some point while ControlService uses it.
            yield return new ResourceEvent("WebService", "DB_Status", ResourceType.DataBlock, OperationType.Delete, now.AddMilliseconds(350), 0);
        }

        public IEnumerable<ResourceEvent> GetLiveEvents()
        {
            var start = DateTime.UtcNow.AddSeconds(1);

            // Normal events that should be allowed based on profiling.
            yield return new ResourceEvent("ControlService", "DB_Pressure", ResourceType.DataBlock, OperationType.Modify, start.AddMilliseconds(0), 1);
            yield return new ResourceEvent("ControlService", "DB_Temperature", ResourceType.DataBlock, OperationType.Modify, start.AddMilliseconds(20), 1);
            yield return new ResourceEvent("LoggerService", "log/runtime.log", ResourceType.File, OperationType.Modify, start.AddMilliseconds(40), 3);

            // Potentially risky events.
            yield return new ResourceEvent("WebService", "DB_Pressure", ResourceType.DataBlock, OperationType.Modify, start.AddMilliseconds(60), 1);
            yield return new ResourceEvent("UnknownService", "DB_Pressure", ResourceType.DataBlock, OperationType.Modify, start.AddMilliseconds(80), 1);

            // Quota stress: large allocation by LoggerService may exceed quota.
            yield return new ResourceEvent("LoggerService", "buf/hist", ResourceType.Buffer, OperationType.Modify, start.AddMilliseconds(100), 50);
        }
    }
}
