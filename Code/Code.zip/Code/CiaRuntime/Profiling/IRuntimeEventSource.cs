using System.Collections.Generic;
using CiaRuntime.Models;

namespace CiaRuntime.Profiling
{
    /// <summary>
    /// Abstraction for sources of resource events, e.g.:
    ///  - virtual PLC traces
    ///  - live hooking / instrumentation
    ///  - replayed logs
    /// </summary>
    public interface IRuntimeEventSource
    {
        IEnumerable<ResourceEvent> GetProfilingEvents();
        IEnumerable<ResourceEvent> GetLiveEvents();
    }
}
