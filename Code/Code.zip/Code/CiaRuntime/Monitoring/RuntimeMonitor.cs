using System;
using System.Collections.Generic;
using CiaRuntime.Models;
using CiaRuntime.Policies;

namespace CiaRuntime.Monitoring
{
    public sealed class MonitorDecision
    {
        public bool IsAllowed { get; }
        public string Reason { get; }

        private MonitorDecision(bool isAllowed, string reason)
        {
            IsAllowed = isAllowed;
            Reason = reason;
        }

        public static MonitorDecision Allow()
        {
            return new MonitorDecision(true, string.Empty);
        }

        public static MonitorDecision Block(string reason)
        {
            return new MonitorDecision(false, reason);
        }
    }

    /// <summary>
    /// Runtime monitor that enforces synthesized policies and
    /// tracks approximate resource usage per (service, resource).
    /// </summary>
    public sealed class RuntimeMonitor
    {
        private readonly PolicySet _policies;
        private readonly Dictionary<(string Service, string Resource), double> _usage;

        public RuntimeMonitor(PolicySet policies)
        {
            _policies = policies;
            _usage = new Dictionary<(string, string), double>(TupleComparer.OrdinalIgnoreCase);
        }

        public MonitorDecision CheckEvent(ResourceEvent ev)
        {
            var rule = _policies.FindRule(ev);
            if (rule == null)
            {
                return MonitorDecision.Block("No matching policy rule for event.");
            }

            if (!rule.AllowedOperations.Contains(ev.OperationType))
            {
                return MonitorDecision.Block(
                    $"Operation {ev.OperationType} is not allowed by the policy.");
            }

            var key = (ev.ServiceName, ev.ResourceId);
            _usage.TryGetValue(key, out var current);

            double next = current;

            switch (ev.OperationType)
            {
                case OperationType.Create:
                case OperationType.Modify:
                    next += ev.Quantity;
                    break;
                case OperationType.Delete:
                    next = 0.0;
                    break;
                case OperationType.Read:
                    break;
            }

            if (rule.MaxQuantity >= 0 && next > rule.MaxQuantity + 1e-6)
            {
                return MonitorDecision.Block(
                    $"Event would exceed quota. Current={current:F2}, Next={next:F2}, Quota={rule.MaxQuantity:F2}.");
            }

            _usage[key] = next;
            return MonitorDecision.Allow();
        }

        private sealed class TupleComparer : IEqualityComparer<(string, string)>
        {
            public static readonly TupleComparer OrdinalIgnoreCase = new TupleComparer();

            public bool Equals((string, string) x, (string, string) y)
            {
                return string.Equals(x.Item1, y.Item1, StringComparison.OrdinalIgnoreCase) &&
                       string.Equals(x.Item2, y.Item2, StringComparison.OrdinalIgnoreCase);
            }

            public int GetHashCode((string, string) obj)
            {
                var h1 = StringComparer.OrdinalIgnoreCase.GetHashCode(obj.Item1);
                var h2 = StringComparer.OrdinalIgnoreCase.GetHashCode(obj.Item2);
                return HashCode.Combine(h1, h2);
            }
        }
    }
}
